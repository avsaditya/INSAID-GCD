'01-Data-Dictionary.csv' contains description of the data.

To import data into python

1. Click on 02-Data.csv

2. A new webpage will open with option 

'Raw'


or

'Download'

in the top right region.

3. Click on 'Raw' or 'Download' which ever is available.

4. A new webpage will open displaying the data.

5. Copy the url and paste it in pd.read_csv('url').

