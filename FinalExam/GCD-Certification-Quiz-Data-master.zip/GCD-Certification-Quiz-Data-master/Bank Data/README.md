'01-Data-Dictionary.csv' contains description of the data.

To import data into python

Click on bank.csv

A new webpage will open with option

'Raw'

or

'Download'

in the top right region.

Click on 'Raw' or 'Download' which ever is available.

A new webpage will open displaying the data.

Copy the url and paste it in pd.read_csv('url').
